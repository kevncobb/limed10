<?php
// @codingStandardsIgnoreFile
use Drupal\Core\Database\Database;

$connection = Database::getConnection();

$query = $connection->update('node_revision__field_viewsreference');
$query->fields(['field_viewsreference_data' => 'a:1:{s:9:"view_mode";s:12:"preview_wide";}']);
$query->condition('revision_id', 2);
$query->execute();
